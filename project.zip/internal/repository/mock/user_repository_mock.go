package repository

import (
	"task-process-service/internal/domain"

	"github.com/stretchr/testify/mock"
)

type MockUserRepository struct {
	mock.Mock
}

func (m *MockUserRepository) Create(task domain.UserAddReq) (int, error) {
	args := m.Called(task)
	return args.Int(0), args.Error(1)
}

func (m *MockUserRepository) GetAll() ([]domain.UserGetDataList, error) {
	args := m.Called()
	return args.Get(0).([]domain.UserGetDataList), args.Error(1)
}

func (m *MockUserRepository) GetById(task domain.UserGetByIdReq) (domain.UserGetDataList, error) {
	args := m.Called(task.Id)
	return args.Get(0).(domain.UserGetDataList), args.Error(1)
}

func (m *MockUserRepository) Update(task domain.UserUpdateReq) (int, error) {
	args := m.Called(task)
	return args.Int(0), args.Error(1)
}

func (m *MockUserRepository) Delete(task domain.UserDeleteReq) (int, error) {
	args := m.Called(task.Id)
	return args.Int(0), args.Error(0)
}
